----//---------------------------------------------------------------------------------------------------\\--
--  Server Hopper by DG Coding Team is                                                                     --
--  licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.   --
--  For more information on this license click here http://creativecommons.org/licenses/by-nc-nd/4.0/      --
----\\---------------------------------------------------------------------------------------------------//--

  SvrHop = {};


  --Name of the window that comes up when you type !servers
  SvrHop.Window_Name = "";

  --Color of the background the buttons sit on
  SvrHop.Background_Color = Color( 179, 0, 0, 235 );

   
  --Color of the buttons you click to connect to servers
  SvrHop.Button_Color = Color( 0, 0, 0, 255 );
 
  --The color of the text on your buttons
  SvrHop.Button_Text_Color = Color( 255, 255, 255, 255 );

  --The servers ip i.e 127.0.0.1:27016
  --The server name i.e "Deathrun"
  SvrHop.Server_1_IP = "Server1IP";
  SvrHop.Server_1_Name = "Server1Name";

  SvrHop.Server_2_IP = "Server2IP";
  SvrHop.Server_2_Name = "Server2Name";

  SvrHop.Server_3_IP = "Server3IP";
  SvrHop.Server_3_Name = "Server3Name";

  SvrHop.Server_4_IP = "Server4IP";
  SvrHop.Server_4_Name = "Server4Name";

