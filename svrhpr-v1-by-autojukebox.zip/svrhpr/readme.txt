
----------------------------------------------------------------
Installation:

1: Take SvrHprAddon and put it in your servers addons folder

2: Configure the options in autorun/svrhprcfg.lua

3: Save the cfg and restart your servers
----------------------------------------------------------------

----------------------------------------------------------------
Support:

My Steam: http://steamcommunity.com/id/AutoJukebox/

My EMail: autojukebox@gmail.com
----------------------------------------------------------------


License:

You are free to use this anywhere, make any changes and upload it anywhere. But it would be nice if you gave me credit for the original addon.